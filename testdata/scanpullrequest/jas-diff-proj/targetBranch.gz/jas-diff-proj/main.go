package main

import (
	"net/http"

	_ "github.com/cloudflare/circl"
	_ "github.com/mattn/go-sqlite3"
)

func main() {

	// serve up static content
	http.Handle("/public/", http.StripPrefix("/public/", http.FileServer(http.Dir("public"))))

	// start the web server
	http.ListenAndServe(":8080", nil)
}
