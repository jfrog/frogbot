package main

import "database/sql"


func openDatabase() (*sql.DB, error) {
	// Open a connection to the SQLite database
	return sql.Open("sqlite3", "data/users.db")
}
