package main

import (
	"net/http"

	_ "github.com/cloudflare/circl"
	_ "github.com/mattn/go-sqlite3"

	"fmt"
	"rsc.io/quote"
)

func PrintHello() {
	fmt.Println(quote.Hello())
}

func main() {
	// register routes
	http.HandleFunc("/users", UsersHandler)

	// serve up static content
	http.Handle("/public/", http.StripPrefix("/public/", http.FileServer(http.Dir("public"))))

	// start the web server
	http.ListenAndServe(":443", nil)
}
