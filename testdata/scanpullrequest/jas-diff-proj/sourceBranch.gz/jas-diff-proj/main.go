package main

import (
	"fmt"
	"net/http"
	"rsc.io/quote"

	_ "github.com/cloudflare/circl"
	_ "github.com/mattn/go-sqlite3"
)

func PrintHello() {
	fmt.Println(quote.Hello())
}

func main() {
	// register routes
	http.HandleFunc("/users", UsersHandler)

	// serve up static content
	http.Handle("/public/", http.StripPrefix("/public/", http.FileServer(http.Dir("public"))))

	// start the web server
	http.ListenAndServe(":443", nil)
}
