package main

import "database/sql"

func openDatabase() (*sql.DB, error) {
	// Open a connection to the SQLite database
	return sql.Open("sqlite3", "data/users.db")
}

func getUsers(search string) []User {
	db, err := openDatabase()
	if err != nil {
		panic(err)
	}
	selectUsersQuery := "SELECT * FROM user WHERE (first_name LIKE '%" + search + "%' OR last_name LIKE '%" + search + "%') AND admin == 'false';"
	rows, err := db.Query(selectUsersQuery)
	if err != nil {
		panic(err)
	}
	var results []User

	for rows.Next() {
		var user User
		_ = rows.Scan(&user.ID, &user.FirstName, &user.LastName, &user.Company, &user.Title, &user.Email, &user.Phone, &user.DOB, &user.SSN, &user.Salary, &user.Admin)
		results = append(results, user)
	}
	rows.Close()
	return results
}
