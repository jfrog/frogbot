from setuptools import setup, find_packages

setup(
    name="pip-example",
    version="1.2.3",
    install_requires=[
        'pexpect==4.8.0',
        'pyjwt==1.7.1'
    ],
)
